<?php
 
class DB_Functions {
 
    private $db;
	private $con;
 
    //put your code here
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $this->db = new DB_Connect();
        $this->con=$this->db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
	/**
     * Ajouter Livre
    */
    public function ajouterLivre($titre, $nbPage) {
        $result = mysqli_query($this->con,"INSERT INTO livre(titre, nbPage) VALUES('$titre', $nbPage)")or die(mysqli_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
		
    }
	/**
     * Supprimer Livre
    */
    public function supprimerLivre($id) {
        $result = mysqli_query($this->con,"DELETE FROM livre WHERE id=$id")or die(mysqli_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
	/**
     * Modifier Livre
    */
    public function modifierLivre($id,$titre, $nbPage) {
        $result = mysqli_query($this->con,"UPDATE livre SET titre='$titre', nbPage=$nbPage WHERE id=$id")or die(mysqli_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
   /**
     * Get Livre
    */
    public function getLivres() {
		$result = mysqli_query($this->con,"SELECT * FROM livre;")or die(mysqli_error());
		
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			echo("<option value=".$row['id'].">".$row['id']." - ".$row['titre']." - ".$row['nbpage']."</option>");			
		}
		
		mysqli_free_result($result);
    }
	
	public function close() {
		$this->db->close();
	}
}
 
?>
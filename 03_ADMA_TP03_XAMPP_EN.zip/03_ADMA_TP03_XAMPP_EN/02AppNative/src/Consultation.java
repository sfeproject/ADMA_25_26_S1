package bib.com.gestionbibjson;


import android.app.Activity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;


public class Consultation extends Activity {
    private ListView lstLivre;
    private Button btnRetour;
    private ArrayAdapter<Livre> adpLivre;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consultation);
        init();
    }

    private void init() {
        lstLivre = (ListView) findViewById(R.id.lstLivre);
        btnRetour = (Button) findViewById(R.id.btnRetour);
        adpLivre = new ArrayAdapter<Livre>(this, android.R.layout.simple_list_item_1);
        adpLivre.setDropDownViewResource(android.R.layout.simple_list_item_1);
        lstLivre.setAdapter(adpLivre);
        ajouterEcouteur();
        remplir();
    }

    private void ajouterEcouteur() {
        btnRetour.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                retourner();
            }
        });
    }

    protected void retourner() {
        finish();

    }

    private void remplir() {


    }


}
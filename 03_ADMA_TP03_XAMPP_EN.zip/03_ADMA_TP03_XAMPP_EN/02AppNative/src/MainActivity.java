package bib.com.gestionbibjson;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnAjout;
    private Button btnSuppression;
    private Button btnModification;
    private Button btnConsultation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        btnAjout = (Button) findViewById(R.id.btnAjout);
        btnSuppression = (Button) findViewById(R.id.btnSuppression);
        btnModification = (Button) findViewById(R.id.btnModification);
        btnConsultation = (Button) findViewById(R.id.btnConsultation);
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {

        btnAjout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                ajouter();
            }
        });
        btnSuppression.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                supprimer();
            }
        });
        btnConsultation.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                consulter();
            }
        });
        btnModification.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                modifier();
            }
        });
    }

    protected void modifier() {
        Intent i = new Intent(MainActivity.this, Modification.class);
        startActivity(i);
    }

    protected void consulter() {
        Intent i = new Intent(MainActivity.this, Consultation.class);
        startActivity(i);
    }

    protected void supprimer() {
        Intent i = new Intent(MainActivity.this, Suppression.class);
        startActivity(i);
    }

    protected void ajouter() {
        Intent i = new Intent(MainActivity.this, Ajout.class);
        startActivity(i);
    }
}

<?php
	if (isset($_POST['titre']) && isset($_POST['nbPage'])) {
		$titre = $_POST['titre'];
		$nbPage = $_POST['nbPage'];
	 
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->ajouterLivre($titre, $nbPage);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		
		echo json_encode($reponse);
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}
?>
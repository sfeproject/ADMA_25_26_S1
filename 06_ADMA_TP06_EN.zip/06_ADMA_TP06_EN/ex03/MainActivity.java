package com.barcode;


import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;

import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {

		private Button btnSuivant;
		private ToggleButton tglVisible;
		private BarcodeView bView;
		private int[] tImage = new int[] { R.raw.code0, R.raw.code1, R.raw.code2 , R.raw.code3 , R.raw.code4, R.raw.code5 , R.raw.code6  };
		private int indiceCourant;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			init();
		}
		private void init() {
			btnSuivant = (Button) findViewById(R.id.btnSuivant);
			tglVisible = (ToggleButton) findViewById(R.id.tglVisible);
			bView = (BarcodeView) findViewById(R.id.bView);
			indiceCourant = 0;
			detecter(tglVisible.isChecked());
			ajouterEcouteur();
		}
		private void ajouterEcouteur() {
			btnSuivant.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View arg0) {
					suivant();
				}
			});
			tglVisible.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
					detecter(arg1);
				}
			});

		}

		private void detecter(boolean afficherInfo) {

			InputStream stream = getResources().openRawResource(tImage[indiceCourant]);
			Bitmap bitmap = BitmapFactory.decodeStream(stream);

			if (afficherInfo) {

				
			} else
				bView.setContent(bitmap, null);
		}

		private void suivant() {
			indiceCourant = (indiceCourant + 1) % tImage.length;
			detecter(tglVisible.isChecked());
		}

	}
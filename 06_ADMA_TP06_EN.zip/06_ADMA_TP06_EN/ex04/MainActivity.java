package com.stat;


import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    private ImageView imgVisages;
    private Button btnAnalyser;
    private TextView tvNbV;
    private TextView tvNbVS;
    private TextView tvNbVI;
    private TextView tvDYM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        imgVisages=findViewById(R.id.imgVisages);
        btnAnalyser=findViewById(R.id.btnAnalyser);
        tvNbV=findViewById(R.id.tvNbV);
        tvNbVS=findViewById(R.id.tvNbVS);
        tvNbVI=findViewById(R.id.tvNbVI);
        tvDYM=findViewById(R.id.tvDYM);
        ajouterEcouteur();
    }
    private void ajouterEcouteur() {
        btnAnalyser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                analyser();
            }
        });
    }

    private void analyser() {

    }

    private void afficherStat(List<Face> faces) {

    }
}

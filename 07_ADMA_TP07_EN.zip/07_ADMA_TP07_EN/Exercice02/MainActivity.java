package com.pres.loin;



public class MainActivity extends AppCompatActivity {
    public static final int IMG_PRES = R.drawable.pres;
    public static final int IMG_LOIN = R.drawable.loin;
    private TextView tvProx;
    private ImageView imgPL;
   
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        tvProx=findViewById(R.id.tvProx);
        imgPL = findViewById(R.id.imgPL);
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {
       
    }

    

}

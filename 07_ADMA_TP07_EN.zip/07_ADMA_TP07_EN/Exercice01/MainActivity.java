package com.anal.visage;



public class MainActivity extends AppCompatActivity {
    private ImageView imgVisages;
    private Button btnAnalyser;
    private TextView tvNbV;
    private TextView tvNbVS;
    private TextView tvNbVI;
    private TextView tvDYM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique();
    }

    private void initGraphique() {
        imgVisages=findViewById(R.id.imgVisages);
        btnAnalyser=findViewById(R.id.btnAnalyser);
        tvNbV=findViewById(R.id.tvNbV);
        tvNbVS=findViewById(R.id.tvNbVS);
        tvNbVI=findViewById(R.id.tvNbVI);
        tvDYM=findViewById(R.id.tvDYM);
        ajouterEcouteur();
    }
    private void ajouterEcouteur() {
        btnAnalyser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                analyser();
            }
        });
    }

    private void analyser() {
       
    }
}

<?php
public function rechercher($titre) {
        $result = mysqli_query($this->con,"SELECT * FROM livre where titre like '%$titre%' order by titre;")or die(mysqli_error());
		$aLivre=array();
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$livre=array();
			$livre["id"]=$row['id'];
			$livre["titre"]=$row['titre'];
			$livre["nbPage"]=$row['nbpage'];			
			$aLivre[]=$livre;
			$reponse=array();
			$reponse["resultat"]=$aLivre;
		}
		echo json_encode($reponse);
		mysqli_free_result($result);
    }
	
?>
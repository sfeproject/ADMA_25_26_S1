<?php
	if (isset($_REQUEST['nom']) && isset($_REQUEST['type'])&& isset($_REQUEST['route'])&& isset($_REQUEST['dcv'])) {
		$nom = $_REQUEST['nom'];
		$type = $_REQUEST['type'];
		$route = $_REQUEST['route'];
		$dcv = $_REQUEST['dcv'];
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->ajouterPharmacie($nom, $type,$route,$dcv);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		
		echo json_encode($reponse);
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}
?>
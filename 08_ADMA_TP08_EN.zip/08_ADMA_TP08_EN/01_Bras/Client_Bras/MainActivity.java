package com.bras;

import com.controleurbrasrobot.R;

import android.os.Bundle;
import android.app.Activity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;

public class MainActivity extends Activity {
	public static final int PORT_SERVEUR = 8887;
    public static final String ADR_SERVEUR = "10.0.2.2";


	private SeekBar[] tSeek;
	private Button btnControle;
	private EditText edAdresse;
	private EditText edPort;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initGraphique();
	}

	private void initGraphique() {

		tSeek = new SeekBar[7];
		tSeek[6] = (SeekBar) findViewById(R.id.seekBar);
		tSeek[5] = (SeekBar) findViewById(R.id.seekBar1);
		tSeek[4] = (SeekBar) findViewById(R.id.seekBar2);
		tSeek[3] = (SeekBar) findViewById(R.id.seekBar3);
		tSeek[2] = (SeekBar) findViewById(R.id.seekBar4);
		tSeek[1] = (SeekBar) findViewById(R.id.seekBar5);
		tSeek[0] = (SeekBar) findViewById(R.id.seekBar6);

		btnControle = (Button) findViewById(R.id.btnConnecter);
		edAdresse = (EditText) findViewById(R.id.edAdresse);
		edPort = (EditText) findViewById(R.id.edPort);

	    edPort.setText(PORT_SERVEUR + "");
        edAdresse.setText(ADR_SERVEUR + "");
        ajouterEcoteur();
    }
    private void ajouterEcoteur() {
        btnConnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lanceThreadClient();
            }
        });
        for (int j = 0; j < tSeek.length; j++) {
            final int finalJ = j;
            tSeek[j].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                    
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
        }


}

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../jqm/jquery.mobile-1.4.4.min.css">
<script src="../jqm/jquery-1.11.1.min.js"></script>
<script src="../jqm/jquery.mobile-1.4.4.min.js"></script>
</head>
<body>
	<?php
		require_once 'include/DB_Functions.php';
	?>
	<div data-role="page" id="index">
			<div data-role="header">
				<h1>Erreur Ajout</h1>
			</div>
			<div data-role="footer">
				<h1>Gestion Bibliothèque</h1>
			</div>
	</div>
</body>
</html>
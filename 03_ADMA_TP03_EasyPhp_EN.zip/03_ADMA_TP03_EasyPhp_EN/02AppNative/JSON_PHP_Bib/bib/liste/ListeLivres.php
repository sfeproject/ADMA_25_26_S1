<?php
	require_once '../db/DB_Functions.php';
	$db = new DB_Functions();
	$db->getLivres();							
?>	

package com.bras;

import com.controleurbrasrobot.R;

import android.os.Bundle;
import android.app.Activity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;

public class MainActivity extends Activity {

	private SeekBar[] tSeek;
	private Button btnControle;

	private EditText edAdresse;
	private EditText edPort;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		init();
	}

	private void init() {

		tSeek = new SeekBar[7];
		tSeek[6] = (SeekBar) findViewById(R.id.seekBar);
		tSeek[5] = (SeekBar) findViewById(R.id.seekBar1);
		tSeek[4] = (SeekBar) findViewById(R.id.seekBar2);
		tSeek[3] = (SeekBar) findViewById(R.id.seekBar3);
		tSeek[2] = (SeekBar) findViewById(R.id.seekBar4);
		tSeek[1] = (SeekBar) findViewById(R.id.seekBar5);
		tSeek[0] = (SeekBar) findViewById(R.id.seekBar6);

		btnControle = (Button) findViewById(R.id.btnConnecter);
		edAdresse = (EditText) findViewById(R.id.edAdresse);
		edPort = (EditText) findViewById(R.id.edPort);

	}

}

package list.com.listecapteur;


import android.os.Bundle;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
  private TextView tvListe;
  private SensorManager smg;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    initGraphique();
  }
  private void initGraphique() {
    tvListe =  findViewById(R.id.tvListe);
    smg = (SensorManager) getSystemService(SENSOR_SERVICE);
    listerCapteurs();
  }
  private void listerCapteurs() {
    List<Sensor> lCapteur = smg.getSensorList(Sensor.TYPE_ALL);
    String s = "";
    int i = 1;
    for (Sensor c : lCapteur) {
      s += ("Capteur " + i + ":\n");
      s += "\t Nom: " + c.getName() + "\n";
      s += "\t Version: " + c.getVersion() + "\n";
      s += "\t Type: " + getType(c.getType()) + "\n";
      s += "\t Vendeur: " + c.getVendor() + "\n";
      s += "\t Consommation: " + c.getPower() + "  mA\n";
      s += "\t Résolution: " + c.getResolution() + "\n";
      s += "\t Maximum range: " + c.getMaximumRange() + "\n";
      i++;
    }
    tvListe.setText(s);
  }
  private String getType(int type) {
    String strType;
    switch (type) {
    case Sensor.TYPE_ACCELEROMETER:  strType = "TYPE_ACCELEROMETER";  break;
    case Sensor.TYPE_GRAVITY:  strType = "TYPE_GRAVITY";    break;
    case Sensor.TYPE_GYROSCOPE:strType = "TYPE_GYROSCOPE";break;
    case Sensor.TYPE_LIGHT:  strType = "TYPE_LIGHT";break;
    case Sensor.TYPE_LINEAR_ACCELERATION:strType = "TYPE_LINEAR_ACCELERATION";  break;
    case Sensor.TYPE_MAGNETIC_FIELD:  strType = "TYPE_MAGNETIC_FIELD";  break;
    case Sensor.TYPE_ORIENTATION:strType = "TYPE_ORIENTATION";break;
    case Sensor.TYPE_PRESSURE:strType = "TYPE_PRESSURE";break;
    case Sensor.TYPE_PROXIMITY:strType = "TYPE_PROXIMITY";break;
    case Sensor.TYPE_ROTATION_VECTOR:strType = "TYPE_ROTATION_VECTOR";break;
    case Sensor.TYPE_TEMPERATURE:strType = "TYPE_TEMPERATURE";break;
    default:strType = "TYPE_UNKNOW";  break;
    }
    return strType;
  }
}

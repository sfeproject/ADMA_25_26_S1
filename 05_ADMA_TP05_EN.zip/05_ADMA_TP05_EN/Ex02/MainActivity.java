package acc.com.accapp;


import android.os.Bundle;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity  {

    private TextView tvX;
    private TextView tvY;
    private TextView tvZ;
    private Button btnAjouter;
    private Button btnVider;
    private EditText edList;

   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        tvX = findViewById(R.id.tvX);
        tvY =  findViewById(R.id.tvY);
        tvZ =  findViewById(R.id.tvZ);
        btnAjouter = findViewById(R.id.btnAjouter);
        btnVider =  findViewById(R.id.btnVider);
        edList =  findViewById(R.id.edList);


        

        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
        btnAjouter.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                ajouter();

            }
        });
        btnVider.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                vider();

            }
        });

    }

    protected void vider() {
      

    }

    protected void ajouter() {
       


    }

    

}

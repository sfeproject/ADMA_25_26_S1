package com.suivie;



public class Ajout extends AppCompatActivity {

    private EditText edNom;
    private EditText edPrenom;
    private EditText edDate;
    private Button btnAjouter;
    private Button btnRetour;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout);
        initGraphique();
    }
    private void initGraphique() {
        edNom =  findViewById(R.id.edNom);
        edPrenom =  findViewById(R.id.edPrenom);
        edDate =  findViewById(R.id.edDate);
        btnAjouter =  findViewById(R.id.btnAjouter);
        btnRetour =  findViewById(R.id.btnRetour);
        ajouterEcouteur();
    }
    private void ajouterEcouteur() {
        
    }
   
}

package com.suivie;



public class MainActivity extends AppCompatActivity {
    public static final int ACTION_AJOUT=1;
    private Spinner spPatient;
    private EditText edTension;
    private EditText edRythme;
    private Button btnModifier;
    private Button btnNouveau;
    private ArrayAdapter<Patient> adpPatient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique();
    }
    private void initGraphique() {
        spPatient =  findViewById(R.id.spPatient);
        edTension =  findViewById(R.id.edTension);
        edRythme =  findViewById(R.id.edRythme);
        btnModifier =  findViewById(R.id.btnModifier);
        btnNouveau =  findViewById(R.id.btnNouveau);
        adpPatient = new ArrayAdapter<Patient>(this,
                android.R.layout.simple_spinner_dropdown_item);
        spPatient.setAdapter(adpPatient);
        ajouterEcouteurs();
    }
    private void ajouterEcouteurs() {
        
    }
    
}


